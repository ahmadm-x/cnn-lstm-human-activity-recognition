
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, TimeDistributed, LSTM, Dense
from tensorflow.keras.optimizers import Adam

def build_model(input_shape=(30, 64, 64, 3), num_classes=3):
    # CNN for feature extraction from a single frame
    cnn = Sequential()
    cnn.add(Conv2D(32, (3, 3), activation='relu', input_shape=(64, 64, 3)))
    cnn.add(MaxPooling2D(pool_size=(2, 2)))
    cnn.add(Flatten())

    # Full model with TimeDistributed CNN + LSTM
    model = Sequential()
    model.add(TimeDistributed(cnn, input_shape=input_shape))
    model.add(LSTM(64))
    model.add(Dense(num_classes, activation='softmax'))

    model.compile(loss='categorical_crossentropy', optimizer=Adam(), metrics=['accuracy'])
    return model

if __name__ == "__main__":
    model = build_model()
    model.summary()
