
# CNN-LSTM Activity Recognition

This project implements a hybrid CNN-LSTM deep learning model to recognize human activities from short video clips. It combines convolutional layers (CNN) to extract spatial features from video frames and recurrent layers (LSTM) to model the temporal sequence of these frames.

## 📌 Project Structure

```
cnn-lstm-activity-recognition/
├── data/                  # Video input samples
│   └── sample_videos/
├── notebooks/             # Jupyter notebooks for development
├── models/                # Trained models will be saved here
├── utils/                 # Video preprocessing scripts
├── main.py                # Model definition and summary
└── README.md              # Project overview and instructions
```

## 🔧 Requirements

- Python 3.8+
- TensorFlow or Keras
- OpenCV (for video preprocessing)
- NumPy, matplotlib

Install dependencies using:

```bash
pip install tensorflow opencv-python numpy matplotlib
```

## 🧠 Model Architecture

- `Conv2D + MaxPooling + Flatten` layers (for spatial feature extraction from each frame)
- `TimeDistributed` wrapper (to apply CNN to each frame)
- `LSTM` layer (to process the time sequence of frame features)
- `Dense` output layer with softmax activation (multi-class classification)

## 🚀 How to Run

```bash
python main.py
```

## 🧪 Future Work

- Load real activity datasets (e.g., UCF101 or HMDB51)
- Improve performance using pretrained CNNs (e.g., MobileNet, ResNet)
- Build a Streamlit or Gradio app for interactive inference

## 📚 Application

Useful in surveillance, health monitoring, smart gyms, and video analysis.
